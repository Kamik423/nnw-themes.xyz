The NewsFax themes uses the ModeSeven font throughout, which is available as Freeware.

Find out more [here](https://www.fontspace.com/modeseven-font-f2369).

ModeSeven is based on the bitmap font in Teletext televisions, 
1980s-vintage Videotext terminals (such as the Prestel system used in 
the UK), and the BBC Micro computer. (The name derives from the BBC 
Micro screen mode which used the teletext character generator.) 

This font looks "natural" at a size of 20 pixels, or any multiple thereof. 
However, it has been hinted as to scale as well as an ex-bitmap font 
can be expected to. 

This font was created by hand with Fontographer 4.1.2 on a Macintosh. 
The character definitions were worked out from a bitmap version of the 
Teletext font created by James Fidell, and included in xbeeb (a BBC 
Micro emulator for UNIX/X11). The spacing of the original has been 
preserved, which is why many character shapes are aligned to the right 
of their cells.