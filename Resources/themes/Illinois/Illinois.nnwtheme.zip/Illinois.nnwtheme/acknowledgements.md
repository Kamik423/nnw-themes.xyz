_Illinois_ uses modified code from Macintosh System 1 from [mazil](https://codepen.io/mazil) on [Codepen](https://codepen.io/mazil/pen/VEymrQ).

_Illinois_ uses Sysfont C from [Alina Sava](https://fontsarena.com/sysfont-by-alina-sava/) and it is available under the [SIL OpenFont License](https://fontsarena.com/licenses-explained/) license.